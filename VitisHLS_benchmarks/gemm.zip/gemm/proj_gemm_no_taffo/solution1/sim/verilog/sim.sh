#!/bin/sh
# ==============================================================
# Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
# Tool Version Limit: 2019.12
# Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
# ==============================================================
# The next line restarts using autoesl tclsh \
    exec /home/bruno/Documents/Vitis_HLS/2022.2/bin/vitis_hls run_sim.tcl
